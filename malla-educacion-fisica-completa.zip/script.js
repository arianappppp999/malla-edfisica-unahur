function toggleDetalle(element) {
  const detalle = element.querySelector(".detalle");
  detalle.style.display = (detalle.style.display === "block") ? "none" : "block";
}
